"""OSIS 命令流 ELEMENT 模块 — 单元(梁/弹簧)创建 + 分组"""

from __future__ import annotations

from pyosis import batch

from pyosis.core.engine import OSISEngine

def build_elements(engine: OSISEngine) -> None:
    # 创建单元（便捷入口，内部转发到对应 create_* 方法）
    engine.element.create(1, "BEAM3D", 1, 2, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(2, "BEAM3D", 2, 3, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(3, "BEAM3D", 3, 4, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(4, "BEAM3D", 4, 5, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(5, "BEAM3D", 5, 6, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(6, "BEAM3D", 6, 7, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(7, "BEAM3D", 7, 8, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(8, "BEAM3D", 8, 9, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(9, "BEAM3D", 9, 10, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(10, "BEAM3D", 10, 11, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(11, "BEAM3D", 11, 12, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(12, "BEAM3D", 12, 13, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(13, "BEAM3D", 13, 14, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(14, "BEAM3D", 14, 15, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(15, "BEAM3D", 15, 16, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(16, "BEAM3D", 16, 17, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(17, "BEAM3D", 17, 18, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(18, "BEAM3D", 18, 19, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(19, "BEAM3D", 19, 20, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(20, "BEAM3D", 20, 21, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(21, "BEAM3D", 21, 22, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(22, "BEAM3D", 22, 23, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(23, "BEAM3D", 23, 24, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(24, "BEAM3D", 24, 25, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(25, "BEAM3D", 25, 26, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(26, "BEAM3D", 26, 27, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(27, "BEAM3D", 27, 28, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(28, "BEAM3D", 28, 29, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(29, "BEAM3D", 29, 30, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(30, "BEAM3D", 30, 31, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(31, "BEAM3D", 31, 32, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(32, "BEAM3D", 32, 33, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(33, "BEAM3D", 33, 34, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(34, "BEAM3D", 34, 35, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(35, "BEAM3D", 35, 36, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(36, "BEAM3D", 36, 37, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(37, "BEAM3D", 37, 38, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(38, "BEAM3D", 38, 39, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(39, "BEAM3D", 39, 40, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(40, "BEAM3D", 40, 41, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(41, "BEAM3D", 41, 42, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(42, "BEAM3D", 42, 43, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(43, "BEAM3D", 43, 44, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(44, "BEAM3D", 44, 45, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(45, "BEAM3D", 45, 46, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(46, "BEAM3D", 46, 47, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(47, "BEAM3D", 47, 48, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(48, "BEAM3D", 48, 49, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(49, "BEAM3D", 49, 50, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(50, "BEAM3D", 50, 51, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(51, "BEAM3D", 51, 52, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    engine.element.create(52, "BEAM3D", 52, 53, 1, 7, 7, 1, 1, 0.0, 0, 0.0, 0)
    # 分配或重置单个单元的理论厚度
    engine.prop.assign_component_thickness(0.3868, "a", "1to52")
    # 创建单元组
    engine.element.group.create("1_车道线单元组", "c")
    engine.element.group.create("1_车道线单元组", "a", "1to52")
    engine.element.group.create("2_车道线单元组", "c")
    engine.element.group.create("2_车道线单元组", "a", "1to52")
    engine.element.group.create("B1单元组", "c")
    engine.element.group.create("B1单元组", "a", "1to52")
    engine.element.group.create("B2单元组", "c")
    engine.element.group.create("B2单元组", "a", "1to52")
    engine.element.group.create("B3单元组", "c")
    engine.element.group.create("B3单元组", "a", "1to52")
    engine.element.group.create("全部", "c")
    engine.element.group.create("全部", "a", "1to52")
    engine.element.group.create("支座", "c")

if __name__ == "__main__":
    from _0_engine import engine
    with batch():
        build_elements(engine)
